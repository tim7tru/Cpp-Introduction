//Timmy Truong
//SYDE 121
//September 12, 2018
#include <iostream>

using namespace std;

int main() {
    int number;
    cout << "Hello World!" << endl;

    cout << "How many programming languages do you know?" << endl;
    cin >> number;

    cout << "You know " << number << " programming languages! WOW!";
    return 0;
}