// Name:        Timmy Truong
// ID:          ID#20772704
// Date:        September 19, 2018
// Course:      SYDE121
// Lab room:    WEEF Lab - E2 1792
// Assignment:  Lab Assignment #1
// Exercise:    Exercise #1
// File Name:   lab02_1.cpp
//              I hereby declare that this code, submitted for credit for the course
//              SYDE121, is a product of my own efforts.  This coded solution has
//              not been plagiarized from other sources and has not been knowingly plagiarized by others.
// Project:     Number of weights calculator

/*
 *
 * OUTLINE OF THE PROGRAM
 * 1. declare variables and input values
 * 2. divide given/total weight by heaviest weight
 * 3. get remainder and divide it by the next heaviest weight
 * 4. repeat until all weight are completed

 * TEST AND VALID RANGES
 * -Tested using iPhone calculator and recorded numbers of weights needed
 *         -1048 worked!
 *         -500 worked!
 *         -32340 worked!
 *         -(-5) worked!
 * -The range of values will work with any integer values
 *         -It will make sense with positive integers as negative weights are undefined
 *         -eg. If -50lb is inputted, the program will tell you that you'll need -1 50lb weight.

 * OUTPUT FOR (a)
 * For 1048 lbs:
 * The amount of 150lb weights needed is: 6
 * The amount of 50lb weights needed is: 2
 * The amount of 30lb weights needed is: 1
 * The amount of 15lb weights needed is: 1
 * The amount of 1lb weights needed is: 3
 *
 */

#include <iostream>

using namespace std;

int main() {
    // declare the initial weight variable
    int weight_given;

    // ask for user input on what the initial weight is
    cout << "What is the initial weight? (in pounds(lbs)) ";
    cin >> weight_given;

    // declare number of weights variables
    // calculate the number of weights required
    int weights150 = weight_given / 150;

    // calculate remainder then divide
    int weights50 = (weight_given % 150) / 50;
    int weights30 = ((weight_given % 150) % 50) / 30;
    int weights15 = (((weight_given % 150) % 50) % 30) / 15;
    int weights1 = ((((weight_given % 150) % 50) % 30) % 15) / 1;

    // print out the total number
    cout << "For " << weight_given << " lbs:" << endl;
    cout << "The amount of 150lb weights needed is: " << weights150 << endl;
    cout << "The amount of 50lb weights needed is: " << weights50 << endl;
    cout << "The amount of 30lb weights needed is: " << weights30 << endl;
    cout << "The amount of 15lb weights needed is: " << weights15 << endl;
    cout << "The amount of 1lb weights needed is: " << weights1 << endl;

    return 0;
}